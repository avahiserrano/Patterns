package es.vase3.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the t3 database table.
 * 
 */
@Entity
public class T3 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="pk_t3")
	private Long pkT3;

	private String name;

	//bi-directional many-to-many association to T1
	@ManyToMany(mappedBy="t3s")
	private List<T1> t1s;

	public T3() {
	}

	public Long getPkT3() {
		return this.pkT3;
	}

	public void setPkT3(Long pkT3) {
		this.pkT3 = pkT3;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<T1> getT1s() {
		return this.t1s;
	}

	public void setT1s(List<T1> t1s) {
		this.t1s = t1s;
	}

}