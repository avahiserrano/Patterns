package es.vase3.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the t1 database table.
 * 
 */
@Entity
public class T1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="pk_t1")
	private Long pkT1;

	private String name;

	//bi-directional many-to-one association to T2
	@OneToMany(mappedBy="t1")
	private List<T2> t2s;

	//bi-directional many-to-many association to T3
	@ManyToMany
	@JoinTable(
		name="t1_t3"
		, joinColumns={
			@JoinColumn(name="pk_t1")
			}
		, inverseJoinColumns={
			@JoinColumn(name="pk_t3")
			}
		)
	private List<T3> t3s;

	public T1() {
	}

	public Long getPkT1() {
		return this.pkT1;
	}

	public void setPkT1(Long pkT1) {
		this.pkT1 = pkT1;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<T2> getT2s() {
		return this.t2s;
	}

	public void setT2s(List<T2> t2s) {
		this.t2s = t2s;
	}

	public T2 addT2(T2 t2) {
		getT2s().add(t2);
		t2.setT1(this);

		return t2;
	}

	public T2 removeT2(T2 t2) {
		getT2s().remove(t2);
		t2.setT1(null);

		return t2;
	}

	public List<T3> getT3s() {
		return this.t3s;
	}

	public void setT3s(List<T3> t3s) {
		this.t3s = t3s;
	}

}