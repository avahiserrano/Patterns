package es.vase3.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the t4 database table.
 * 
 */
@Entity
public class T4 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="pk_t4")
	private Long pkT4;

	private String name;

	//bi-directional many-to-one association to T4
	@ManyToOne
	@JoinColumn(name="pk_t4_auto")
	private T4 t4;

	//bi-directional many-to-one association to T4
	@OneToMany(mappedBy="t4")
	private List<T4> t4s;

	public T4() {
	}

	public Long getPkT4() {
		return this.pkT4;
	}

	public void setPkT4(Long pkT4) {
		this.pkT4 = pkT4;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public T4 getT4() {
		return this.t4;
	}

	public void setT4(T4 t4) {
		this.t4 = t4;
	}

	public List<T4> getT4s() {
		return this.t4s;
	}

	public void setT4s(List<T4> t4s) {
		this.t4s = t4s;
	}

	public T4 addT4(T4 t4) {
		getT4s().add(t4);
		t4.setT4(this);

		return t4;
	}

	public T4 removeT4(T4 t4) {
		getT4s().remove(t4);
		t4.setT4(null);

		return t4;
	}

}