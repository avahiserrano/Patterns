package es.vase3.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the t2 database table.
 * 
 */
@Entity
public class T2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="pk_t2")
	private Long pkT2;

	private String name;

	//bi-directional many-to-one association to T1
	@ManyToOne
	@JoinColumn(name="pk_t1")
	private T1 t1;

	public T2() {
	}

	public Long getPkT2() {
		return this.pkT2;
	}

	public void setPkT2(Long pkT2) {
		this.pkT2 = pkT2;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public T1 getT1() {
		return this.t1;
	}

	public void setT1(T1 t1) {
		this.t1 = t1;
	}

}