package es.vase3.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.event.ActionEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import es.vase3.dao.TaskDao;
import es.vase3.model.Task;

@Component("taskBB")
@Scope("session")
@ManagedBean(name="taskBB")
public class TaskBackingBean {

	private static final Logger logger = LoggerFactory.getLogger(TaskBackingBean.class);

	private Task task;
	
	@Autowired(required = true)
	private TaskDao taskDao;

	private List<Task> tasks;  

	public TaskDao getTaskDao() {
		return taskDao;
	}

	public void setTaskDao(TaskDao taskDao) {
		this.taskDao = taskDao;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	public void setTasks(List<Task> tasks) {
		logger.debug("Set tasks " + tasks);
		this.tasks = tasks;
	}

    @PostConstruct
    public void init(){ 
    	task = new Task();
    	tasks = new ArrayList<Task>();
    }

	public String getMessage() {
		logger.debug("Returning message from task home bean");
		return "Hello from Spring";
	}	

	public Task getTask() {
		return task;
	}

	public void saveTask(ActionEvent actionEvent) {
		task = taskDao.save(task);
		task = new Task();
		invalidateTasks();
		tasks = taskDao.findAll();
	}

	private void invalidateTasks() {
		tasks = null;
		tasks = new ArrayList<Task>();
	}

	public List<Task> getTasks() {
		return tasks;		
	}
}
