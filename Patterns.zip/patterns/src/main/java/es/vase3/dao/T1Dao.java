package es.vase3.dao;

import es.vase3.model.T1;

public interface T1Dao extends GenericRepositoryInterface<T1> {

}
