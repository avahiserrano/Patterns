package es.vase3.dao;

import es.vase3.model.T3;

public class T3DaoImpl extends GenericRepositoryImplementation<T3> {

}
