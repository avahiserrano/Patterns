package es.vase3.dao;

import org.springframework.stereotype.Repository;

import es.vase3.model.Task;

@Repository
public class TaskDaoImpl extends GenericRepositoryImplementation<Task> implements TaskDao {
    
	public TaskDaoImpl(){
		super();
		super.setType(Task.class);
	}
}
