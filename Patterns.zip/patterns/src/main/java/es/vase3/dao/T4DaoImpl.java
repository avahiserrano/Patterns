package es.vase3.dao;

import es.vase3.model.T4;

public class T4DaoImpl extends GenericRepositoryImplementation<T4> {

}
