package es.vase3.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/*
Attribute	Required?	Default	Description
name
Yes
 	
Method name(s) with which the transaction attributes are to be associated. The wildcard (*) character can be used to associate the same transaction attribute settings with a number of methods; for example, get*, handle*, on*Event, and so forth.
propagation
No
REQUIRED
Transaction propagation behavior.
isolation
No
DEFAULT
Transaction isolation level.
timeout
No
-1
Transaction timeout value (in seconds).
read-only
No
false
Is this transaction read-only?
rollback-for
No
 	
Exception(s) that trigger rollback; comma-delimited. For example, com.foo.MyBusinessException,ServletException.
no-rollback-for
No
 	
Exception(s) that do not trigger rollback; comma-delimited. For example, com.foo.MyBusinessException,ServletException.

 */

@Repository
public class GenericRepositoryImplementation<T> implements GenericRepositoryInterface<T>{
	      
	private static final Logger logger = LoggerFactory.getLogger(GenericRepositoryImplementation.class);
	
	@PersistenceContext
	protected EntityManager entityManager;
	
	protected Class<T> type;

	public Class<T> getType() {
		return type;
	}

	public void setType(Class<T> type) {
		this.type = type;
	}

	public GenericRepositoryImplementation() {
		// TODO Auto-generated constructor stub

	}

	public GenericRepositoryImplementation(Class<T> type) {
		// TODO Auto-generated constructor stub

		this.type = type;
	}
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Transactional
	public T save(T entity) {
		entityManager.persist(entity);
		entityManager.flush();
		return entity;
	}

	@Transactional
	public Boolean delete(T entity) {
		// TODO Auto-generated method stub
		try {
		     entityManager.remove(entity);
		} catch (Exception ex) {
			return false;
		}
		return true;
	}

	@Transactional
	public T edit(T entity) {
		// TODO Auto-generated method stub
		try{
		   return entityManager.merge(entity);
		} catch(Exception ex) {
			return null;
		}
	}
	
	@Transactional
	public T find(Long id) {
		// TODO Auto-generated method stub
		return (T) entityManager.find( type, id);
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<T> findAll() {
		List<T> list = null;
		try{
			list = entityManager.createQuery("Select t from " + type.getSimpleName() + " t").getResultList();
		} catch (Exception e){
			list = new ArrayList<T>();
		}
		return list; 	
	}
}
