package es.vase3.dao;

import es.vase3.model.T3;

public interface T3Dao extends GenericRepositoryInterface<T3> {

}
