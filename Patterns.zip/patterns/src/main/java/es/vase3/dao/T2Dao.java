package es.vase3.dao;

import es.vase3.model.T2;

public interface T2Dao extends GenericRepositoryInterface<T2> {

}
