package es.vase3.dao;

import es.vase3.model.T4;

public interface T4Dao extends GenericRepositoryInterface<T4> {

}
