package es.vase3.dao;

import org.springframework.stereotype.Component;

import es.vase3.model.Task;

public interface TaskDao extends GenericRepositoryInterface<Task> {
		
}
