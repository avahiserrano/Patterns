package es.vase3.dao;

import java.util.List;

public interface GenericRepositoryInterface<T> {

	public T save(T entity);
	public Boolean delete(T entity);
	public T edit(T entity);
	public T find(Long id);
	public List<T> findAll();
}
