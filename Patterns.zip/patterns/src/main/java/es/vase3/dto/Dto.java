package es.vase3.dto;

import java.util.List;
import java.util.Map;

import es.vase3.pojos.AnotherPojo;
import es.vase3.pojos.Pojo;

// This is the Generic Dto for this portlet
public interface Dto<G extends AttributeGroup> {
    public static final Attribute<AttributeGroup, Pojo> pojo = Attribute.getInstance("POJO");
    public static final Attribute<AttributeGroup, AnotherPojo> anotherPojo = Attribute.getInstance("ANOTHER_POJO");
    public static final Attribute<AttributeGroup, List<?>> genericList = Attribute.getInstance("GENERIC_LIST");
    public static final Attribute<AttributeGroup, Map<?, ?>> genericHashMap = Attribute.getInstance("GENERIC_MAP");
}
