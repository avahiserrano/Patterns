package es.vase3.pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AnotherPojo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3886759695753540576L;
	private String value = "";
	private List<AnotherPojo> anotherPojoList = new ArrayList<AnotherPojo>();

	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public List<AnotherPojo> getAnotherPojoList() {
		return anotherPojoList;
	}
	public void setAnotherPojoList(List<AnotherPojo> anotherPojoList) {
		this.anotherPojoList = anotherPojoList;
	}
}
